import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Heart, Copy, Check, QrCode } from "lucide-react";
import { useState } from "react";
import { useLocation } from "wouter";

export default function PixDonation() {
  const { user, loading, error, isAuthenticated, logout } = useAuth();
  const [, setLocation] = useLocation();
  const [copied, setCopied] = useState(false);

  // Extrair valor da URL
  const params = new URLSearchParams(window.location.search);
  const amount = params.get("amount") || "0";

  const pixData = {
    cnpj: "12.345.678/0001-90",
    pixKey: "12.345.678/0001-90",
    pixKeyEmail: "apae@itajai.org.br",
    institution: "APAE Itajaí",
    bankData: {
      bank: "Itaú",
      agency: "1234",
      account: "567890-X",
    },
  };

  const handleCopyPix = () => {
    navigator.clipboard.writeText(pixData.pixKey);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleCopyEmail = () => {
    navigator.clipboard.writeText(pixData.pixKeyEmail);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="min-h-screen flex flex-col bg-white">
      {/* Header/Navigation */}
      <header className="sticky top-0 z-50 bg-white border-b border-gray-200 shadow-sm">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-green-600 rounded-full flex items-center justify-center">
              <Heart className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-800">APAE Itajaí</h1>
              <p className="text-xs text-gray-600">Associação de Pais e Amigos dos Excepcionais</p>
            </div>
          </div>
          <nav className="hidden md:flex gap-8">
            <a href="/" className="text-gray-700 hover:text-green-600 font-medium transition">Início</a>
            <a href="/donate" className="text-gray-700 hover:text-green-600 font-medium transition">Doação</a>
            <a href="/partnerships" className="text-gray-700 hover:text-green-600 font-medium transition">Parcerias</a>
          </nav>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero Section */}
        <section className="w-full bg-gradient-to-r from-green-600 to-green-700 py-16 md:py-24 px-4">
          <div className="container mx-auto text-center text-white">
            <div className="flex justify-center mb-6">
              <QrCode className="w-16 h-16" />
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Confirme Sua Doação via PIX</h1>
            <p className="text-lg md:text-xl mb-8 max-w-2xl mx-auto">
              Utilize uma das chaves PIX abaixo para completar sua doação de forma segura e instantânea.
            </p>
          </div>
        </section>

        {/* Valor da Doação */}
        {amount !== "0" && (
          <section className="py-8 px-4 bg-green-50">
            <div className="container mx-auto text-center">
              <p className="text-gray-700 mb-2">Valor da doação:</p>
              <p className="text-4xl font-bold text-green-600">R$ {parseInt(amount).toLocaleString('pt-BR')}</p>
            </div>
          </section>
        )}

        {/* Chaves PIX */}
        <section className="py-16 md:py-24 px-4">
          <div className="container mx-auto max-w-3xl">
            <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 text-gray-800">
              Chaves PIX Disponíveis
            </h2>

            <div className="space-y-6">
              {/* PIX por CNPJ */}
              <Card className="p-8 border-2 border-green-200">
                <h3 className="text-2xl font-bold text-gray-800 mb-4">PIX por CNPJ</h3>
                <p className="text-gray-600 mb-6">
                  Copie o CNPJ da instituição e utilize em seu aplicativo bancário:
                </p>
                <div className="bg-gray-50 p-4 rounded-lg mb-4 flex items-center justify-between">
                  <code className="text-lg font-mono font-bold text-gray-800">{pixData.cnpj}</code>
                  <button
                    onClick={handleCopyPix}
                    className="flex items-center gap-2 px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg transition"
                  >
                    {copied ? (
                      <>
                        <Check className="w-5 h-5" />
                        Copiado!
                      </>
                    ) : (
                      <>
                        <Copy className="w-5 h-5" />
                        Copiar
                      </>
                    )}
                  </button>
                </div>
                <p className="text-sm text-gray-600">
                  ✓ Doação instantânea e segura
                </p>
              </Card>

              {/* PIX por Email */}
              <Card className="p-8 border-2 border-green-200">
                <h3 className="text-2xl font-bold text-gray-800 mb-4">PIX por Email</h3>
                <p className="text-gray-600 mb-6">
                  Copie o email da instituição e utilize em seu aplicativo bancário:
                </p>
                <div className="bg-gray-50 p-4 rounded-lg mb-4 flex items-center justify-between">
                  <code className="text-lg font-mono font-bold text-gray-800">{pixData.pixKeyEmail}</code>
                  <button
                    onClick={handleCopyEmail}
                    className="flex items-center gap-2 px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg transition"
                  >
                    {copied ? (
                      <>
                        <Check className="w-5 h-5" />
                        Copiado!
                      </>
                    ) : (
                      <>
                        <Copy className="w-5 h-5" />
                        Copiar
                      </>
                    )}
                  </button>
                </div>
                <p className="text-sm text-gray-600">
                  ✓ Doação instantânea e segura
                </p>
              </Card>

              {/* Dados Bancários */}
              <Card className="p-8 border-2 border-orange-200">
                <h3 className="text-2xl font-bold text-gray-800 mb-4">Transferência Bancária</h3>
                <p className="text-gray-600 mb-6">
                  Se preferir, você pode fazer uma transferência bancária:
                </p>
                <div className="space-y-3 bg-gray-50 p-4 rounded-lg">
                  <div>
                    <p className="text-sm text-gray-600">Banco</p>
                    <p className="font-bold text-gray-800">{pixData.bankData.bank}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Agência</p>
                    <p className="font-bold text-gray-800">{pixData.bankData.agency}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Conta</p>
                    <p className="font-bold text-gray-800">{pixData.bankData.account}</p>
                  </div>
                </div>
              </Card>
            </div>
          </div>
        </section>

        {/* Instruções */}
        <section className="py-16 md:py-24 px-4 bg-gray-50">
          <div className="container mx-auto max-w-3xl">
            <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 text-gray-800">
              Como Fazer a Doação
            </h2>

            <div className="space-y-6">
              <div className="flex gap-4">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center h-10 w-10 rounded-full bg-green-600 text-white font-bold">
                    1
                  </div>
                </div>
                <div>
                  <h3 className="text-xl font-bold text-gray-800 mb-2">Abra seu Banco</h3>
                  <p className="text-gray-600">
                    Abra o aplicativo do seu banco ou acesse o site de sua instituição financeira.
                  </p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center h-10 w-10 rounded-full bg-green-600 text-white font-bold">
                    2
                  </div>
                </div>
                <div>
                  <h3 className="text-xl font-bold text-gray-800 mb-2">Selecione PIX</h3>
                  <p className="text-gray-600">
                    Escolha a opção "PIX" ou "Transferência PIX" no menu de transações.
                  </p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center h-10 w-10 rounded-full bg-green-600 text-white font-bold">
                    3
                  </div>
                </div>
                <div>
                  <h3 className="text-xl font-bold text-gray-800 mb-2">Cole a Chave PIX</h3>
                  <p className="text-gray-600">
                    Cole uma das chaves PIX acima (CNPJ ou Email) no campo de destinatário.
                  </p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center h-10 w-10 rounded-full bg-green-600 text-white font-bold">
                    4
                  </div>
                </div>
                <div>
                  <h3 className="text-xl font-bold text-gray-800 mb-2">Digite o Valor</h3>
                  <p className="text-gray-600">
                    Digite o valor que deseja doar e confirme a transação.
                  </p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center h-10 w-10 rounded-full bg-green-600 text-white font-bold">
                    5
                  </div>
                </div>
                <div>
                  <h3 className="text-xl font-bold text-gray-800 mb-2">Pronto!</h3>
                  <p className="text-gray-600">
                    Sua doação foi processada instantaneamente. Você receberá um comprovante por email.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Final */}
        <section className="py-16 md:py-24 px-4 bg-gradient-to-r from-green-600 to-green-700">
          <div className="container mx-auto text-center text-white">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              Obrigado por Sua Generosidade!
            </h2>
            <p className="text-lg md:text-xl mb-8 max-w-2xl mx-auto">
              Sua doação faz uma diferença real na vida de crianças e adolescentes com deficiência.
            </p>
            <a href="/donate">
              <Button className="bg-white text-green-600 hover:bg-gray-100 px-12 py-6 text-lg font-semibold">
                Voltar para Doações
              </Button>
            </a>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-12 px-4">
        <div className="container mx-auto">
          <div className="grid md:grid-cols-3 gap-8 mb-8">
            <div>
              <h3 className="font-bold text-lg mb-4">APAE Itajaí</h3>
              <p className="text-gray-400 text-sm">
                Associação de Pais e Amigos dos Excepcionais - Transformando vidas através da inclusão.
              </p>
            </div>
            <div>
              <h3 className="font-bold text-lg mb-4">Contato</h3>
              <p className="text-gray-400 text-sm">Telefone: (47) 3245-1234</p>
              <p className="text-gray-400 text-sm">Email: contato@apaeitajai.org.br</p>
            </div>
            <div>
              <h3 className="font-bold text-lg mb-4">CNPJ</h3>
              <p className="text-gray-400 text-sm">CNPJ: {pixData.cnpj}</p>
            </div>
          </div>
          <div className="border-t border-gray-700 pt-8 text-center text-gray-400 text-sm">
            <p>&copy; 2026 APAE Itajaí. Todos os direitos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
